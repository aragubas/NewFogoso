#! /bin/bash
./NewFogoso