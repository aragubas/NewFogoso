All taiyou scripts MUST be on Scripts Folder.


[taiyou_dict.data] <- This file contains all avaliable commands
[instructions_agr_size_dict.data] <- This file contains all the commands tsup and it's minimal arguments size
